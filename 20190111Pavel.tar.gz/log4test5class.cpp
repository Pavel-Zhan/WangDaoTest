 ///
 /// @file    log4test5class.cpp
 /// @author  Pavel(1786447581@qq.com)
 /// @date    2019-01-12 01:35:37
 ///
#include "log4test5class.h"
#include <iostream>
#include <log4cpp/Category.hh>
#include <log4cpp/Appender.hh>
#include <log4cpp/FileAppender.hh>
#include <log4cpp/RollingFileAppender.hh>
#include <log4cpp/OstreamAppender.hh>
#include <log4cpp/Priority.hh>
#include <log4cpp/PatternLayout.hh>
using std::cout;
using std::endl;


class Mylogger
{

public:

	void warn(const char* msg)
	{
		_root->warn(catMsg(msg));
	}

	void error(const char* msg)
	{
		_root->error(catMsg(msg));
	}

	void debug(const char* msg)
	{
		_root->debug(catMsg(msg));
	}

	void info(const char* msg)
	{
		_root->info(catMsg(msg));
	}

	static Mylogger* getInstance()
	{
		if(nullptr == _logger)
		{
			_logger = new Mylogger();
		
			log4cpp::OstreamAppender* osAppender1 = new log4cpp::OstreamAppender("osAppender1",&cout);
			log4cpp::PatternLayout* pLayout1 = new log4cpp::PatternLayout();
			pLayout1->setConversionPattern("%d: %p %c %x: %m%n");
			osAppender1->setLayout(pLayout1);

			log4cpp::RollingFileAppender* fileAppender = new log4cpp::RollingFileAppender("rollingFileAppender",
																						"rolling.log",
																						5*1024,
																						3);
			log4cpp::PatternLayout* pLayout2 = new log4cpp::PatternLayout();
			pLayout2->setConversionPattern("%d %c [%p] %m%n");
			fileAppender->setLayout(pLayout2);

			log4cpp::Category& root = log4cpp::Category::getRoot();
			_root = & root;
			_root->addAppender(osAppender1);
			_root->addAppender(fileAppender);
			root.setPriority(log4cpp::Priority::DEBUG);
		}
		return _logger;
	}

	static void destory()
	{
		if(_logger)
			delete _logger;
		log4cpp::Category::shutdown();
	}

private:

	Mylogger() {cout << "Mylogger()" <<endl;}
	~Mylogger() {cout << "~Mylogger()" <<endl;}

private:
	static Mylogger* _logger;
	static log4cpp::Category* _root;
};

Mylogger* Mylogger::_logger = nullptr;
log4cpp::Category* Mylogger::_root = nullptr;
 
int main(void)
{
	Mylogger* log = Mylogger::getInstance();
	log->warn("hello");
	log->error("there is a mistake need to be fixed.");
	log->destory();
	return 0;
}
