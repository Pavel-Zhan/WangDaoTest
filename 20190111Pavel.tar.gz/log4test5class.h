 ///
 /// @file    log4test5class.h
 /// @author  Pavel(1786447581@qq.com)
 /// @date    2019-01-12 04:16:43
 ///

#ifndef _LOG4TEST5CLASS_H_
#define _LOG4TEST5CLASS_H_

#include <iostream>
#include <string>
#include <sstream>

using std::string;
using std::ostringstream;
inline string int2string(int lineNumber)
{
	ostringstream oss;
	oss << lineNumber;
	return oss.str();
}

#define catMsg(msg) string(msg).append("{fileName:")\
	.append(__FILE__).append("functionName:")\
	.append(__func__).append("lineNumber:")\
	.append(int2string(__LINE__)).append("}").c_str()

#endif
